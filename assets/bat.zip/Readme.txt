An alternative option for the animation is to create morphs from Bat_-_Vamp object to Bat_-_Vam1-2-3-4...   This sequence is loopable and duration should be around 15 frames for the whole loop.

Due to conversion some texture maps may be missing in the material:

This is the list of the proper texture map assigments:

bat.jpg ----> Diffuse color
bat_spl.jpg ----> Specular level (don't need to be at 100%)
bat_spc.jpg ----> Specular color (don't need to be at 100%)
Bat_op.jpg ----> Opacity
Bat_spl.jpg ----> Bump
Bat_trans.jpg ----> Translucency (mono)
Bat_trans2.jpg ----> Translucency (color)


Support and more 3D models available from:

------------------------------
Jesus

jesped@gmail.com
msn:  jesped@hotmail.com
yahoo:  jesped.geo@yahoo.com
icq: 126003458
------------------------------